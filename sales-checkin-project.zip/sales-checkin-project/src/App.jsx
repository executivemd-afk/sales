import { useState, useRef, useEffect } from "react";

// ========== GOOGLE SHEETS API CONFIG ==========
// Web app URL จาก Google Apps Script (Deploy → Manage deployments)
const API_URL = "https://script.google.com/macros/s/AKfycbznJ3JDiY16my7qppmdBEK1hdbI1BrVTvi4yWhA9kCl0hhU-yS4s_w_l3YMA4aLZnrR/exec";

// ดึงข้อมูลจาก Google Sheets ผ่าน Apps Script (GET)
const apiGet = async (action) => {
  try {
    const res = await fetch(`${API_URL}?action=${action}`);
    const data = await res.json();
    if (Array.isArray(data)) return data;
    return null; // error response เช่น {error: "..."}
  } catch (err) {
    console.warn(`apiGet(${action}) failed:`, err);
    return null;
  }
};

// ส่งข้อมูลไป Google Sheets ผ่าน Apps Script (POST)
// หมายเหตุ: ใช้ mode "no-cors" เพราะ Apps Script ไม่รองรับ CORS header แบบเต็มรูปแบบ
// ผลคือเราจะไม่เห็น response กลับมา (อ่านผลลัพธ์ไม่ได้) แต่ข้อมูลจะถูกเขียนเข้า Sheets จริง
const apiPost = async (action, payload) => {
  try {
    await fetch(API_URL, {
      method: "POST",
      mode: "no-cors",
      body: JSON.stringify({ action, ...payload }),
    });
    return true; // no-cors ไม่ให้อ่านสถานะจริง ถือว่าส่งสำเร็จถ้าไม่ throw
  } catch (err) {
    console.warn(`apiPost(${action}) failed:`, err);
    return false;
  }
};

// ========== PERSISTENT STORAGE HELPERS (fallback เมื่อ API ใช้ไม่ได้) ==========
const loadStorage = async (key, fallback) => {
  try {
    const res = await window.storage.get(key);
    return res ? JSON.parse(res.value) : fallback;
  } catch { return fallback; }
};
const saveStorage = async (key, value) => {
  try { await window.storage.set(key, JSON.stringify(value)); } catch {}
};

// ========== DEFAULT DATA ==========
const DEFAULT_REPS = [
  { id: "S001", name: "สมชาย ใจดี", phone: "081-234-5678", zone: "เหนือ" },
  { id: "S002", name: "สุภาพร มั่นคง", phone: "082-345-6789", zone: "อีสาน" },
  { id: "S003", name: "วิชัย รุ่งเรือง", phone: "083-456-7890", zone: "ตะวันออก" },
  { id: "S004", name: "นภา สดใส", phone: "084-567-8901", zone: "ใต้" },
];

const DEFAULT_CUSTOMERS = [
  { id: "C001", name: "ร้านโชห่วยทองคำ", province: "เชียงใหม่", type: "โชห่วย", contact: "คุณสมศรี" },
  { id: "C002", name: "ร้านมินิมาร์ทสุขใจ", province: "เชียงใหม่", type: "มินิมาร์ท", contact: "คุณวิชิต" },
  { id: "C003", name: "ห้างสรรพสินค้ากลางเมือง", province: "ขอนแก่น", type: "ห้าง", contact: "คุณพรทิพย์" },
  { id: "C004", name: "ร้านสะดวกซื้อดาวทอง", province: "ชลบุรี", type: "สะดวกซื้อ", contact: "คุณธนา" },
];

const DEFAULT_CHECKINS = [
  { id: 1, repId: "S001", repName: "สมชาย ใจดี", shopId: "C001", shopName: "ร้านโชห่วยทองคำ", province: "เชียงใหม่", status: "met", note: "สั่งสินค้าเพิ่ม 3 รายการ", time: "2025-06-18T09:15:00", hasPhoto: true, salesAmount: 4500 },
  { id: 2, repId: "S001", repName: "สมชาย ใจดี", shopId: "C002", shopName: "ร้านมินิมาร์ทสุขใจ", province: "เชียงใหม่", status: "not_met", note: "เจ้าของไปธุระ", time: "2025-06-18T10:30:00", hasPhoto: true, salesAmount: 0 },
  { id: 3, repId: "S002", repName: "สุภาพร มั่นคง", shopId: "C003", shopName: "ห้างสรรพสินค้ากลางเมือง", province: "ขอนแก่น", status: "met", note: "ต่อสัญญาประจำปี", time: "2025-06-18T08:45:00", hasPhoto: true, salesAmount: 12000 },
  { id: 4, repId: "S003", repName: "วิชัย รุ่งเรือง", shopId: "C004", shopName: "ร้านสะดวกซื้อดาวทอง", province: "ชลบุรี", status: "closed", note: "ร้านปิดปรับปรุง", time: "2025-06-18T11:00:00", hasPhoto: false, salesAmount: 0 },
];

const PROVINCES = ["กรุงเทพมหานคร","เชียงใหม่","เชียงราย","ลำปาง","แม่ฮ่องสอน","ขอนแก่น","อุดรธานี","นครราชสีมา","อุบลราชธานี","สกลนคร","ชลบุรี","ระยอง","จันทบุรี","สงขลา","ภูเก็ต","สุราษฎร์ธานี","นครศรีธรรมราช","พิษณุโลก","นครสวรรค์","สุพรรณบุรี"];
const ZONES = ["เหนือ","อีสาน","กลาง","ตะวันออก","ตะวันตก","ใต้","กรุงเทพฯ"];
const SHOP_TYPES = ["โชห่วย","มินิมาร์ท","ห้าง","สะดวกซื้อ","ซูเปอร์มาร์เก็ต","ร้านยา","อื่นๆ"];
const STATUS_OPTIONS = [
  { value: "met", label: "เข้าพบได้", color: "#22c55e" },
  { value: "not_met", label: "ไม่พบเจ้าของ", color: "#f59e0b" },
  { value: "closed", label: "ร้านปิด", color: "#ef4444" },
  { value: "new", label: "ร้านใหม่", color: "#3b82f6" },
];

// ========== HELPERS ==========
const fmt = (iso) => new Date(iso).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
const fmtDate = (iso) => new Date(iso).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
const getStatus = (v) => STATUS_OPTIONS.find((s) => s.value === v) || STATUS_OPTIONS[0];
const genId = (prefix, list) => {
  const nums = list.map(i => parseInt(i.id.replace(prefix, ""), 10)).filter(Boolean);
  const next = nums.length ? Math.max(...nums) + 1 : 1;
  return `${prefix}${String(next).padStart(3, "0")}`;
};

// ========== TOAST ==========
const Toast = ({ msg, type = "success", onClose }) => {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  const bg = type === "success" ? "#16a34a" : type === "line" ? "#06C755" : "#dc2626";
  return (
    <div style={{ position: "fixed", bottom: 24, right: 16, left: 16, zIndex: 9999, display: "flex", justifyContent: "center" }}>
      <div style={{ background: bg, color: "#fff", borderRadius: 14, padding: "14px 20px", maxWidth: 380, width: "100%", boxShadow: "0 8px 32px rgba(0,0,0,0.25)", display: "flex", alignItems: "flex-start", gap: 12, animation: "slideUp 0.3s ease" }}>
        <span style={{ fontSize: 20 }}>{type === "line" ? "💬" : type === "success" ? "✅" : "❌"}</span>
        <div style={{ flex: 1, fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-line" }}>{msg}</div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "#fff", cursor: "pointer", fontSize: 18 }}>×</button>
      </div>
    </div>
  );
};

// ========== SHEETS MODAL ==========
const SheetsModal = ({ data, onClose }) => {
  const headers = ["เวลา","รหัสเซลล์","ชื่อเซลล์","ร้านค้า","จังหวัด","สถานะ","ยอดขาย (฿)","หมายเหตุ"];
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div style={{ background: "#fff", borderRadius: 16, width: "100%", maxWidth: 900, maxHeight: "85vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 24px 64px rgba(0,0,0,0.25)" }}>
        <div style={{ background: "#0f9d58", padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 22 }}>📊</span>
            <div>
              <div style={{ color: "#fff", fontWeight: 700, fontSize: 15 }}>Sales_Checkin_Report.xlsx</div>
              <div style={{ color: "#b7f0d4", fontSize: 11 }}>Google Sheets — อัปเดตล่าสุด: เมื่อกี้</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 8, padding: "6px 14px", cursor: "pointer", fontWeight: 600 }}>✕ ปิด</button>
        </div>
        <div style={{ overflowX: "auto", overflowY: "auto", flex: 1 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ background: "#e8f5e9", position: "sticky", top: 0 }}>
                {headers.map((h, i) => <th key={i} style={{ padding: "10px 12px", textAlign: "left", fontWeight: 700, color: "#1a5e36", borderBottom: "2px solid #a5d6a7", whiteSpace: "nowrap" }}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {data.map((row, i) => (
                <tr key={row.id} style={{ background: i % 2 === 0 ? "#fff" : "#f9fdf9" }}>
                  <td style={{ padding: "9px 12px", color: "#555", whiteSpace: "nowrap" }}>{fmt(row.time)}</td>
                  <td style={{ padding: "9px 12px", fontWeight: 700, color: "#1565c0" }}>{row.repId}</td>
                  <td style={{ padding: "9px 12px" }}>{row.repName}</td>
                  <td style={{ padding: "9px 12px", fontWeight: 600 }}>{row.shopName}</td>
                  <td style={{ padding: "9px 12px", color: "#555" }}>{row.province}</td>
                  <td style={{ padding: "9px 12px" }}>
                    <span style={{ background: getStatus(row.status).color + "22", color: getStatus(row.status).color, padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700 }}>{getStatus(row.status).label}</span>
                  </td>
                  <td style={{ padding: "9px 12px", fontWeight: 700, color: row.salesAmount > 0 ? "#0f9d58" : "#999" }}>{row.salesAmount > 0 ? row.salesAmount.toLocaleString() : "-"}</td>
                  <td style={{ padding: "9px 12px", color: "#666", maxWidth: 200 }}>{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ padding: "12px 20px", background: "#f5fdf8", borderTop: "1px solid #c8e6c9", fontSize: 12, color: "#555", display: "flex", gap: 24 }}>
          <span>รวม {data.length} รายการ</span>
          <span>ยอดขายรวม: <strong style={{ color: "#0f9d58" }}>฿{data.reduce((s, r) => s + r.salesAmount, 0).toLocaleString()}</strong></span>
        </div>
      </div>
    </div>
  );
};

// ========== CHECKIN FORM ==========
const CheckinForm = ({ reps, customers, onSubmit, onCancel, lockedRepId }) => {
  const [step, setStep] = useState(lockedRepId ? 2 : 1);
  const [repId, setRepId] = useState(lockedRepId || "");
  const [shopId, setShopId] = useState("");
  const [customShop, setCustomShop] = useState("");
  const [province, setProvince] = useState("");
  const [status, setStatus] = useState("met");
  const [note, setNote] = useState("");
  const [salesAmount, setSalesAmount] = useState("");
  const [photoPreview, setPhotoPreview] = useState(null);
  const [useCustomShop, setUseCustomShop] = useState(false);
  const fileRef = useRef();

  const selectedRep = reps.find((r) => r.id === repId);
  const selectedShop = customers.find((c) => c.id === shopId);

  useEffect(() => {
    if (selectedShop && !useCustomShop) setProvince(selectedShop.province);
  }, [selectedShop, useCustomShop]);

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhotoPreview(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleSubmit = () => {
    const shopName = useCustomShop ? customShop : (selectedShop?.name || "");
    if (!repId || !shopName || !province) return;
    onSubmit({
      repId, repName: selectedRep?.name || "",
      shopId: useCustomShop ? "" : shopId,
      shopName, province, status, note,
      salesAmount: Number(salesAmount) || 0,
      hasPhoto: !!photoPreview,
      time: new Date().toISOString(),
    });
  };

  const inp = { width: "100%", padding: "11px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#fafbfc" };
  const btn = (active, color = "#1a56db") => ({
    flex: 1, background: active ? color : "#cbd5e1", color: "#fff", border: "none",
    borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 700,
    cursor: active ? "pointer" : "not-allowed",
  });

  return (
    <div>
      <div style={{ display: "flex", gap: 6, marginBottom: 24 }}>
        {[1, 2, 3].map((s) => (
          <div key={s} style={{ flex: 1, height: 4, borderRadius: 99, background: step >= s ? "#1a56db" : "#e0e7ef", transition: "background 0.3s" }} />
        ))}
      </div>

      {step === 1 && !lockedRepId && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#1e2d4a" }}>👤 ขั้นตอน 1: เลือกพนักงานขาย</div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>รหัสเซลล์ *</label>
            <select value={repId} onChange={(e) => setRepId(e.target.value)} style={{ ...inp, cursor: "pointer" }}>
              <option value="">— เลือกพนักงาน —</option>
              {reps.map((r) => <option key={r.id} value={r.id}>{r.id} – {r.name} ({r.zone})</option>)}
            </select>
          </div>
          {selectedRep && (
            <div style={{ background: "#eff6ff", border: "1.5px solid #bfdbfe", borderRadius: 10, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: "50%", background: "#1a56db", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 15 }}>{selectedRep.name[0]}</div>
              <div>
                <div style={{ fontWeight: 700, color: "#1e40af" }}>{selectedRep.name}</div>
                <div style={{ fontSize: 12, color: "#3b82f6" }}>{selectedRep.id} · โซน{selectedRep.zone} · {selectedRep.phone}</div>
              </div>
            </div>
          )}
          <button onClick={() => repId && setStep(2)} style={btn(!!repId)}>ถัดไป →</button>
        </div>
      )}

      {step === 2 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#1e2d4a" }}>🏪 ขั้นตอน 2: ข้อมูลร้านค้า</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setUseCustomShop(false)} style={{ flex: 1, padding: "9px", border: `2px solid ${!useCustomShop ? "#1a56db" : "#e0e7ef"}`, background: !useCustomShop ? "#eff6ff" : "#fff", borderRadius: 10, cursor: "pointer", fontWeight: 600, fontSize: 13, color: !useCustomShop ? "#1a56db" : "#64748b" }}>เลือกจากรายการ</button>
            <button onClick={() => setUseCustomShop(true)} style={{ flex: 1, padding: "9px", border: `2px solid ${useCustomShop ? "#1a56db" : "#e0e7ef"}`, background: useCustomShop ? "#eff6ff" : "#fff", borderRadius: 10, cursor: "pointer", fontWeight: 600, fontSize: 13, color: useCustomShop ? "#1a56db" : "#64748b" }}>ร้านใหม่</button>
          </div>
          {!useCustomShop ? (
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>เลือกร้านค้า *</label>
              <select value={shopId} onChange={(e) => setShopId(e.target.value)} style={{ ...inp, cursor: "pointer" }}>
                <option value="">— เลือกร้านค้า —</option>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.name} · {c.province}</option>)}
              </select>
              {selectedShop && (
                <div style={{ background: "#f0fdf4", border: "1.5px solid #bbf7d0", borderRadius: 10, padding: "10px 14px", marginTop: 8 }}>
                  <div style={{ fontWeight: 700, color: "#15803d", fontSize: 13 }}>{selectedShop.name}</div>
                  <div style={{ fontSize: 12, color: "#4ade80" }}>{selectedShop.province} · {selectedShop.type} · {selectedShop.contact}</div>
                </div>
              )}
            </div>
          ) : (
            <>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ชื่อร้านค้า *</label>
                <input value={customShop} onChange={(e) => setCustomShop(e.target.value)} placeholder="เช่น ร้านทองคำพาณิช" style={inp} />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>จังหวัด *</label>
                <select value={province} onChange={(e) => setProvince(e.target.value)} style={{ ...inp, cursor: "pointer" }}>
                  <option value="">— เลือกจังหวัด —</option>
                  {PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            </>
          )}
          {!useCustomShop && selectedShop && (
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 8 }}>สถานะ</label>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {STATUS_OPTIONS.map((s) => (
                  <div key={s.value} onClick={() => setStatus(s.value)} style={{ border: `2px solid ${status === s.value ? s.color : "#e0e7ef"}`, background: status === s.value ? s.color + "15" : "#fff", borderRadius: 10, padding: "10px 12px", cursor: "pointer", fontWeight: 600, fontSize: 13, color: status === s.value ? s.color : "#64748b" }}>{s.label}</div>
                ))}
              </div>
            </div>
          )}
          {useCustomShop && (
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 8 }}>สถานะ</label>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {STATUS_OPTIONS.map((s) => (
                  <div key={s.value} onClick={() => setStatus(s.value)} style={{ border: `2px solid ${status === s.value ? s.color : "#e0e7ef"}`, background: status === s.value ? s.color + "15" : "#fff", borderRadius: 10, padding: "10px 12px", cursor: "pointer", fontWeight: 600, fontSize: 13, color: status === s.value ? s.color : "#64748b" }}>{s.label}</div>
                ))}
              </div>
            </div>
          )}
          <div style={{ display: "flex", gap: 10 }}>
            {!lockedRepId && <button onClick={() => setStep(1)} style={{ ...btn(true, "#94a3b8"), flex: "0 0 80px" }}>← กลับ</button>}
            <button onClick={() => { const ok = useCustomShop ? (customShop && province) : shopId; if (ok) setStep(3); }} style={btn(!!(useCustomShop ? (customShop && province) : shopId))}>ถัดไป →</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#1e2d4a" }}>📸 ขั้นตอน 3: รายละเอียด & ภาพ</div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ภาพถ่ายหน้าร้าน</label>
            <div onClick={() => fileRef.current.click()} style={{ border: "2px dashed #bfdbfe", borderRadius: 12, padding: photoPreview ? 0 : "24px", textAlign: "center", cursor: "pointer", background: "#f8faff", overflow: "hidden" }}>
              {photoPreview ? (
                <div style={{ position: "relative" }}>
                  <img src={photoPreview} alt="preview" style={{ width: "100%", maxHeight: 180, objectFit: "cover", display: "block" }} />
                  <div style={{ position: "absolute", top: 8, right: 8, background: "#1a56db", color: "#fff", borderRadius: 6, padding: "3px 8px", fontSize: 11 }}>✓ เพิ่มแล้ว</div>
                </div>
              ) : (
                <>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>📷</div>
                  <div style={{ color: "#1a56db", fontWeight: 600, fontSize: 13 }}>แตะเพื่ออัปโหลดภาพ</div>
                  <div style={{ color: "#94a3b8", fontSize: 11, marginTop: 4 }}>JPG, PNG</div>
                </>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display: "none" }} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ยอดขาย (฿)</label>
            <input type="number" value={salesAmount} onChange={(e) => setSalesAmount(e.target.value)} placeholder="0" style={inp} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>หมายเหตุ</label>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="บันทึกรายละเอียด..." rows={3} style={{ ...inp, resize: "none" }} />
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setStep(2)} style={{ ...btn(true, "#94a3b8"), flex: "0 0 80px" }}>← กลับ</button>
            <button onClick={handleSubmit} style={btn(true, "#16a34a")}>✓ ยืนยันเช็กอิน</button>
          </div>
        </div>
      )}
    </div>
  );
};

// ========== ADMIN: REPS MANAGER ==========
const RepsManager = ({ reps, setReps, showToast }) => {
  const [form, setForm] = useState(null); // null=list, {}=add, {..}=edit
  const [search, setSearch] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const filtered = reps.filter((r) => r.name.includes(search) || r.id.includes(search) || r.zone.includes(search));
  const inp = { width: "100%", padding: "11px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#fafbfc" };

  const handleSave = () => {
    if (!form.name || !form.zone) return;
    if (form._editing) {
      const updated = reps.map((r) => r.id === form.id ? { ...form } : r);
      setReps(updated);
      saveStorage("reps", updated);
      showToast("✅ แก้ไขข้อมูลพนักงานแล้ว");
    } else {
      const newRep = { ...form, id: genId("S", reps) };
      const updated = [...reps, newRep];
      setReps(updated);
      saveStorage("reps", updated);
      showToast("✅ เพิ่มพนักงานใหม่แล้ว");
    }
    setForm(null);
  };

  const handleDelete = (id) => {
    const updated = reps.filter((r) => r.id !== id);
    setReps(updated);
    saveStorage("reps", updated);
    setDeleteConfirm(null);
    showToast("🗑️ ลบพนักงานแล้ว");
  };

  if (form !== null) return (
    <div style={{ padding: "0 0 16px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <button onClick={() => setForm(null)} style={{ background: "#f1f5f9", border: "none", borderRadius: 8, padding: "7px 14px", cursor: "pointer", fontWeight: 600, color: "#475569" }}>← กลับ</button>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#1e293b" }}>{form._editing ? "แก้ไขพนักงาน" : "เพิ่มพนักงานใหม่"}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {form._editing && <div style={{ background: "#eff6ff", borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#1e40af", fontWeight: 600 }}>รหัส: {form.id}</div>}
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ชื่อ-นามสกุล *</label>
          <input value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="เช่น สมชาย ใจดี" style={inp} />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>เบอร์โทรศัพท์</label>
          <input value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="0xx-xxx-xxxx" style={inp} />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>โซนพื้นที่ *</label>
          <select value={form.zone || ""} onChange={(e) => setForm({ ...form, zone: e.target.value })} style={{ ...inp, cursor: "pointer" }}>
            <option value="">— เลือกโซน —</option>
            {ZONES.map((z) => <option key={z} value={z}>{z}</option>)}
          </select>
        </div>
        <button onClick={handleSave} disabled={!form.name || !form.zone} style={{ background: form.name && form.zone ? "#1a56db" : "#cbd5e1", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 700, cursor: form.name && form.zone ? "pointer" : "not-allowed" }}>
          {form._editing ? "💾 บันทึกการแก้ไข" : "➕ เพิ่มพนักงาน"}
        </button>
      </div>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 ค้นหาพนักงาน..." style={{ flex: 1, padding: "10px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 13, outline: "none", fontFamily: "inherit" }} />
        <button onClick={() => setForm({ name: "", phone: "", zone: "" })} style={{ background: "#1a56db", color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", fontSize: 13, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap" }}>+ เพิ่ม</button>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.map((rep) => (
          <div key={rep.id} style={{ background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1.5px solid #f1f5f9", display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 42, height: 42, borderRadius: "50%", background: "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, color: "#1a56db", fontSize: 16, flexShrink: 0 }}>{rep.name[0]}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, color: "#1e293b", fontSize: 14 }}>{rep.name}</div>
              <div style={{ fontSize: 12, color: "#94a3b8" }}>{rep.id} · โซน{rep.zone}{rep.phone ? ` · ${rep.phone}` : ""}</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => setForm({ ...rep, _editing: true })} style={{ background: "#eff6ff", border: "none", borderRadius: 8, padding: "7px 12px", cursor: "pointer", color: "#1a56db", fontWeight: 600, fontSize: 12 }}>✏️ แก้ไข</button>
              <button onClick={() => setDeleteConfirm(rep.id)} style={{ background: "#fff0f0", border: "none", borderRadius: 8, padding: "7px 12px", cursor: "pointer", color: "#dc2626", fontWeight: 600, fontSize: 12 }}>🗑️</button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 24 }}>ไม่พบข้อมูล</div>}
      </div>
      {deleteConfirm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: 24, maxWidth: 320, width: "100%" }}>
            <div style={{ fontSize: 32, textAlign: "center", marginBottom: 12 }}>⚠️</div>
            <div style={{ fontWeight: 700, textAlign: "center", marginBottom: 8 }}>ยืนยันการลบ?</div>
            <div style={{ color: "#64748b", textAlign: "center", fontSize: 13, marginBottom: 20 }}>ข้อมูลพนักงาน "{reps.find(r => r.id === deleteConfirm)?.name}" จะถูกลบถาวร</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setDeleteConfirm(null)} style={{ flex: 1, background: "#f1f5f9", border: "none", borderRadius: 10, padding: "11px", cursor: "pointer", fontWeight: 600 }}>ยกเลิก</button>
              <button onClick={() => handleDelete(deleteConfirm)} style={{ flex: 1, background: "#dc2626", color: "#fff", border: "none", borderRadius: 10, padding: "11px", cursor: "pointer", fontWeight: 700 }}>ลบ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ========== ADMIN: CUSTOMERS MANAGER ==========
const CustomersManager = ({ customers, setCustomers, showToast }) => {
  const [form, setForm] = useState(null);
  const [search, setSearch] = useState("");
  const [filterProvince, setFilterProvince] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const filtered = customers.filter((c) =>
    (c.name.includes(search) || c.id.includes(search) || c.contact?.includes(search)) &&
    (filterProvince === "" || c.province === filterProvince)
  );
  const inp = { width: "100%", padding: "11px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#fafbfc" };

  const handleSave = () => {
    if (!form.name || !form.province) return;
    if (form._editing) {
      const updated = customers.map((c) => c.id === form.id ? { ...form } : c);
      setCustomers(updated);
      saveStorage("customers", updated);
      showToast("✅ แก้ไขข้อมูลลูกค้าแล้ว");
    } else {
      const newC = { ...form, id: genId("C", customers) };
      const updated = [...customers, newC];
      setCustomers(updated);
      saveStorage("customers", updated);
      showToast("✅ เพิ่มลูกค้าใหม่แล้ว");
    }
    setForm(null);
  };

  const handleDelete = (id) => {
    const updated = customers.filter((c) => c.id !== id);
    setCustomers(updated);
    saveStorage("customers", updated);
    setDeleteConfirm(null);
    showToast("🗑️ ลบข้อมูลลูกค้าแล้ว");
  };

  if (form !== null) return (
    <div style={{ padding: "0 0 16px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <button onClick={() => setForm(null)} style={{ background: "#f1f5f9", border: "none", borderRadius: 8, padding: "7px 14px", cursor: "pointer", fontWeight: 600, color: "#475569" }}>← กลับ</button>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#1e293b" }}>{form._editing ? "แก้ไขลูกค้า" : "เพิ่มลูกค้าใหม่"}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {form._editing && <div style={{ background: "#f0fdf4", borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#15803d", fontWeight: 600 }}>รหัส: {form.id}</div>}
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ชื่อร้านค้า *</label>
          <input value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="เช่น ร้านโชห่วยทองคำ" style={inp} />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ประเภทร้าน</label>
          <select value={form.type || ""} onChange={(e) => setForm({ ...form, type: e.target.value })} style={{ ...inp, cursor: "pointer" }}>
            <option value="">— เลือกประเภท —</option>
            {SHOP_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>จังหวัด *</label>
          <select value={form.province || ""} onChange={(e) => setForm({ ...form, province: e.target.value })} style={{ ...inp, cursor: "pointer" }}>
            <option value="">— เลือกจังหวัด —</option>
            {PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>ชื่อผู้ติดต่อ</label>
          <input value={form.contact || ""} onChange={(e) => setForm({ ...form, contact: e.target.value })} placeholder="เช่น คุณสมศรี" style={inp} />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>หมายเหตุ</label>
          <textarea value={form.note || ""} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="ข้อมูลเพิ่มเติม..." rows={2} style={{ ...inp, resize: "none" }} />
        </div>
        <button onClick={handleSave} disabled={!form.name || !form.province} style={{ background: form.name && form.province ? "#16a34a" : "#cbd5e1", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 700, cursor: form.name && form.province ? "pointer" : "not-allowed" }}>
          {form._editing ? "💾 บันทึกการแก้ไข" : "➕ เพิ่มลูกค้า"}
        </button>
      </div>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 ค้นหาร้านค้า..." style={{ flex: 1, padding: "10px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 13, outline: "none", fontFamily: "inherit" }} />
        <button onClick={() => setForm({ name: "", province: "", type: "", contact: "", note: "" })} style={{ background: "#16a34a", color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", fontSize: 13, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap" }}>+ เพิ่ม</button>
      </div>
      <select value={filterProvince} onChange={(e) => setFilterProvince(e.target.value)} style={{ width: "100%", padding: "9px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 13, outline: "none", fontFamily: "inherit", marginBottom: 14, background: "#fafbfc" }}>
        <option value="">ทุกจังหวัด ({customers.length})</option>
        {[...new Set(customers.map(c => c.province))].map((p) => <option key={p} value={p}>{p}</option>)}
      </select>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.map((c) => (
          <div key={c.id} style={{ background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1.5px solid #f1f5f9", display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 42, height: 42, borderRadius: 10, background: "#f0fdf4", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>🏪</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 700, color: "#1e293b", fontSize: 14 }}>{c.name}</div>
              <div style={{ fontSize: 12, color: "#94a3b8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.id}{c.type ? ` · ${c.type}` : ""} · {c.province}{c.contact ? ` · ${c.contact}` : ""}</div>
            </div>
            <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
              <button onClick={() => setForm({ ...c, _editing: true })} style={{ background: "#eff6ff", border: "none", borderRadius: 8, padding: "7px 12px", cursor: "pointer", color: "#1a56db", fontWeight: 600, fontSize: 12 }}>✏️</button>
              <button onClick={() => setDeleteConfirm(c.id)} style={{ background: "#fff0f0", border: "none", borderRadius: 8, padding: "7px 12px", cursor: "pointer", color: "#dc2626", fontWeight: 600, fontSize: 12 }}>🗑️</button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 24 }}>ไม่พบข้อมูล</div>}
      </div>
      {deleteConfirm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: 24, maxWidth: 320, width: "100%" }}>
            <div style={{ fontSize: 32, textAlign: "center", marginBottom: 12 }}>⚠️</div>
            <div style={{ fontWeight: 700, textAlign: "center", marginBottom: 8 }}>ยืนยันการลบ?</div>
            <div style={{ color: "#64748b", textAlign: "center", fontSize: 13, marginBottom: 20 }}>"{customers.find(c => c.id === deleteConfirm)?.name}" จะถูกลบถาวร</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setDeleteConfirm(null)} style={{ flex: 1, background: "#f1f5f9", border: "none", borderRadius: 10, padding: "11px", cursor: "pointer", fontWeight: 600 }}>ยกเลิก</button>
              <button onClick={() => handleDelete(deleteConfirm)} style={{ flex: 1, background: "#dc2626", color: "#fff", border: "none", borderRadius: 10, padding: "11px", cursor: "pointer", fontWeight: 700 }}>ลบ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ========== DAILY SUMMARY ==========
const DailySummary = ({ checkins }) => {
  const byRep = {};
  checkins.forEach((c) => {
    if (!byRep[c.repId]) byRep[c.repId] = { repId: c.repId, repName: c.repName, items: [] };
    byRep[c.repId].items.push(c);
  });
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {Object.values(byRep).map((rep) => {
        const total = rep.items.reduce((s, i) => s + i.salesAmount, 0);
        const met = rep.items.filter((i) => i.status === "met").length;
        return (
          <div key={rep.repId} style={{ background: "#fff", borderRadius: 14, border: "1.5px solid #e8edf5", overflow: "hidden" }}>
            <div style={{ background: "#1e3a5f", padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{rep.repName}</div>
                <div style={{ color: "#7dd3fc", fontSize: 11 }}>{rep.repId}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ color: "#4ade80", fontWeight: 800, fontSize: 16 }}>฿{total.toLocaleString()}</div>
                <div style={{ color: "#94a3b8", fontSize: 10 }}>เข้าพบได้ {met}/{rep.items.length}</div>
              </div>
            </div>
            {rep.items.map((item, idx) => {
              const st = getStatus(item.status);
              return (
                <div key={item.id} style={{ padding: "11px 16px", borderTop: idx > 0 ? "1px solid #f1f5f9" : "none", display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: st.color, flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: "#1e293b" }}>{item.shopName}</div>
                    <div style={{ fontSize: 11, color: "#94a3b8" }}>{item.province} · {fmt(item.time)}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 11, color: st.color, fontWeight: 700 }}>{st.label}</div>
                    {item.salesAmount > 0 && <div style={{ fontSize: 12, color: "#16a34a", fontWeight: 600 }}>฿{item.salesAmount.toLocaleString()}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        );
      })}
      {Object.keys(byRep).length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>ยังไม่มีข้อมูลวันนี้</div>}
    </div>
  );
};

// ========== ROLES ==========
const ROLES = {
  admin:   { label: "ผู้ดูแลระบบ (Admin)", color: "#7c3aed", can: { manage: true, viewAll: true, editOwn: true } },
  manager: { label: "ผู้จัดการ (Manager)",  color: "#0891b2", can: { manage: false, viewAll: true, editOwn: false } },
  sales:   { label: "พนักงานขาย (Sales)",   color: "#1a56db", can: { manage: false, viewAll: false, editOwn: true } },
};

// ========== LOGIN SCREEN ==========
const LoginScreen = ({ reps, onLogin }) => {
  const [role, setRole] = useState("");
  const [repId, setRepId] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  // PIN ทดลอง — ใช้สำหรับ admin/manager หรือเซลล์ที่ยังไม่มี pin ในชีต
  const DEMO_PIN = "1234";

  const handleSubmit = () => {
    if (!role) { setError("กรุณาเลือกบทบาท"); return; }
    if (role === "sales" && !repId) { setError("กรุณาเลือกรหัสเซลล์"); return; }

    const rep = reps.find((r) => r.id === repId);

    // ถ้าเป็นเซลล์และมี pin จริงในชีต (จาก Google Sheets) ให้เช็คกับ pin จริง
    if (role === "sales" && rep && rep.pin) {
      if (String(pin) !== String(rep.pin)) { setError("รหัส PIN ไม่ถูกต้อง"); return; }
    } else {
      if (pin !== DEMO_PIN) { setError(`รหัส PIN ไม่ถูกต้อง (ทดลองใช้: ${DEMO_PIN})`); return; }
    }

    onLogin({ role, repId: role === "sales" ? repId : null, repName: rep?.name || ROLES[role].label });
  };

  const inp = { width: "100%", padding: "12px 14px", border: "1.5px solid #e0e7ef", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#fafbfc" };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #1e3a5f 0%, #1a56db 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, fontFamily: "'Sarabun', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700;800&display=swap'); * { box-sizing: border-box; } input:focus, select:focus { border-color: #1a56db !important; background: #fff !important; }`}</style>
      <div style={{ background: "#fff", borderRadius: 20, padding: 28, width: "100%", maxWidth: 380, boxShadow: "0 24px 64px rgba(0,0,0,0.3)" }}>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>🗺️</div>
          <div style={{ fontWeight: 800, fontSize: 19, color: "#1e293b" }}>Sales Check-in</div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>เข้าสู่ระบบเพื่อเริ่มใช้งาน</div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 8 }}>เลือกบทบาทของคุณ *</label>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {Object.entries(ROLES).map(([key, r]) => (
                <div key={key} onClick={() => { setRole(key); setError(""); }} style={{
                  border: `2px solid ${role === key ? r.color : "#e0e7ef"}`,
                  background: role === key ? r.color + "12" : "#fff",
                  borderRadius: 10, padding: "11px 14px", cursor: "pointer",
                  display: "flex", alignItems: "center", gap: 10, transition: "all 0.2s",
                }}>
                  <div style={{ width: 10, height: 10, borderRadius: "50%", background: r.color, flexShrink: 0 }} />
                  <span style={{ fontWeight: role === key ? 700 : 500, color: role === key ? r.color : "#475569", fontSize: 13 }}>{r.label}</span>
                </div>
              ))}
            </div>
          </div>

          {role === "sales" && (
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>รหัสเซลล์ *</label>
              <select value={repId} onChange={(e) => { setRepId(e.target.value); setError(""); }} style={{ ...inp, cursor: "pointer" }}>
                <option value="">— เลือกรหัสเซลล์ —</option>
                {reps.map((r) => <option key={r.id} value={r.id}>{r.id} – {r.name}</option>)}
              </select>
            </div>
          )}

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#64748b", display: "block", marginBottom: 6 }}>รหัส PIN *</label>
            <input type="password" value={pin} onChange={(e) => { setPin(e.target.value); setError(""); }} placeholder="••••" maxLength={4} style={inp} onKeyDown={(e) => e.key === "Enter" && handleSubmit()} />
            <div style={{ fontSize: 11, color: "#cbd5e1", marginTop: 5 }}>ทดลองใช้ PIN: 1234</div>
          </div>

          {error && <div style={{ background: "#fef2f2", color: "#dc2626", borderRadius: 8, padding: "9px 12px", fontSize: 12, fontWeight: 600 }}>⚠️ {error}</div>}

          <button onClick={handleSubmit} style={{ background: "#1a56db", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 700, cursor: "pointer", marginTop: 6 }}>เข้าสู่ระบบ →</button>
        </div>
      </div>
    </div>
  );
};

// ========== MAIN APP ==========
export default function App() {
  const [user, setUser] = useState(null); // {role, repId, repName}
  const [tab, setTab] = useState("checkin");
  const [adminTab, setAdminTab] = useState("reps");
  const [reps, setReps] = useState(DEFAULT_REPS);
  const [customers, setCustomers] = useState(DEFAULT_CUSTOMERS);
  const [checkins, setCheckins] = useState(DEFAULT_CHECKINS);
  const [showForm, setShowForm] = useState(false);
  const [showSheets, setShowSheets] = useState(false);
  const [toast, setToast] = useState(null);
  const [nextId, setNextId] = useState(10);
  const [loaded, setLoaded] = useState(false);

  // Load data: ลองดึงจาก Google Sheets API ก่อน ถ้าใช้ไม่ได้ใช้ mock storage แทน
  const [usingApi, setUsingApi] = useState(false);

  useEffect(() => {
    (async () => {
      const [apiReps, apiCustomers, apiCheckins] = await Promise.all([
        apiGet("getReps"),
        apiGet("getCustomers"),
        apiGet("getCheckins"),
      ]);

      const apiWorking = apiReps !== null && apiCustomers !== null && apiCheckins !== null;
      setUsingApi(apiWorking);

      if (apiWorking) {
        setReps(apiReps.length ? apiReps : DEFAULT_REPS);
        setCustomers(apiCustomers.length ? apiCustomers : DEFAULT_CUSTOMERS);
        setCheckins(apiCheckins);
      } else {
        const [r, c, ch] = await Promise.all([
          loadStorage("reps", DEFAULT_REPS),
          loadStorage("customers", DEFAULT_CUSTOMERS),
          loadStorage("checkins", DEFAULT_CHECKINS),
        ]);
        setReps(r); setCustomers(c); setCheckins(ch);
      }
      setLoaded(true);
    })();
  }, []);

  if (!loaded) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f0f4f8", fontFamily: "Sarabun, sans-serif" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>🗺️</div>
        <div style={{ color: "#64748b" }}>กำลังโหลด...</div>
      </div>
    </div>
  );

  if (!user) return <LoginScreen reps={reps} onLogin={setUser} />;

  const perms = ROLES[user.role].can;
  const visibleCheckins = perms.viewAll ? checkins : checkins.filter((c) => c.repId === user.repId);

  const showToast = (msg, type = "success") => setToast({ msg, type });

  const handleCheckin = async (data) => {
    const newItem = { ...data, id: nextId };
    setNextId((n) => n + 1);
    const updated = [newItem, ...checkins];
    setCheckins(updated);
    setShowForm(false);

    if (usingApi) {
      apiPost("addCheckin", data); // ยิงพื้นหลัง ไม่รอผล (no-cors อ่านผลไม่ได้อยู่แล้ว)
    } else {
      saveStorage("checkins", updated);
    }

    const st = getStatus(data.status);
    showToast(`📍 ${data.repName}\n🏪 ${data.shopName} · ${data.province}\n${st.label}${data.salesAmount > 0 ? ` · ฿${data.salesAmount.toLocaleString()}` : ""}`, "line");
  };

  const handleLogout = () => { setUser(null); setTab("checkin"); };

  const todayTotal = visibleCheckins.reduce((s, c) => s + c.salesAmount, 0);
  const todayMet = visibleCheckins.filter((c) => c.status === "met").length;

  const TABS = [
    { id: "checkin", label: "📋 ประวัติ" },
    { id: "summary", label: "📈 สรุปรายวัน" },
    ...(perms.manage ? [{ id: "admin", label: "⚙️ จัดการ" }] : []),
  ];

  if (!loaded) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f0f4f8", fontFamily: "Sarabun, sans-serif" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>🗺️</div>
        <div style={{ color: "#64748b" }}>กำลังโหลด...</div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#f0f4f8", fontFamily: "'Sarabun', 'Noto Sans Thai', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        input:focus, select:focus, textarea:focus { border-color: #1a56db !important; background: #fff !important; }
        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
        ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
      `}</style>

      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      {showSheets && <SheetsModal data={checkins} onClose={() => setShowSheets(false)} />}

      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #1e3a5f 0%, #1a56db 100%)", padding: "20px 20px 0", position: "sticky", top: 0, zIndex: 100, boxShadow: "0 4px 20px rgba(26,86,219,0.3)" }}>
        <div style={{ maxWidth: 480, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div>
              <div style={{ color: "#fff", fontWeight: 800, fontSize: 18 }}>🗺️ Sales Check-in</div>
              <div style={{ color: "#93c5fd", fontSize: 12 }}>{fmtDate(new Date().toISOString())}</div>
            </div>
            <button onClick={() => setShowSheets(true)} style={{ background: "#0f9d58", border: "none", color: "#fff", borderRadius: 10, padding: "8px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
              📊 Sheets
            </button>
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(255,255,255,0.1)", borderRadius: 10, padding: "8px 12px", marginBottom: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: ROLES[user.role].color }} />
              <span style={{ color: "#fff", fontSize: 12, fontWeight: 600 }}>{user.repName}</span>
              <span style={{ color: "#93c5fd", fontSize: 11 }}>· {ROLES[user.role].label}</span>
            </div>
            <button onClick={handleLogout} style={{ background: "none", border: "none", color: "#fca5a5", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>ออกจากระบบ</button>
          </div>
          <div style={{ textAlign: "center", marginBottom: 10 }}>
            <span style={{
              fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 99,
              background: usingApi ? "rgba(34,197,94,0.2)" : "rgba(251,191,36,0.2)",
              color: usingApi ? "#86efac" : "#fde68a",
            }}>
              {usingApi ? "🟢 เชื่อมต่อ Google Sheets จริง" : "🟡 โหมดทดลอง (ข้อมูลจำลอง — ยังไม่เชื่อม Sheets)"}
            </span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 16 }}>
            {[
              { label: "เช็กอินวันนี้", value: visibleCheckins.length, unit: "ครั้ง", color: "#60a5fa" },
              { label: "เข้าพบได้", value: todayMet, unit: "ร้าน", color: "#4ade80" },
              { label: "ยอดขายรวม", value: "฿" + (todayTotal >= 1000 ? (todayTotal / 1000).toFixed(1) + "K" : todayTotal), unit: "", color: "#fbbf24" },
            ].map((s) => (
              <div key={s.label} style={{ background: "rgba(255,255,255,0.12)", borderRadius: 10, padding: "10px 12px" }}>
                <div style={{ color: s.color, fontWeight: 800, fontSize: 18 }}>{s.value}<span style={{ fontSize: 11, fontWeight: 400 }}> {s.unit}</span></div>
                <div style={{ color: "#cbd5e1", fontSize: 10, marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 0 }}>
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, padding: "10px", border: "none", cursor: "pointer", background: "none", color: tab === t.id ? "#fff" : "#93c5fd", fontWeight: tab === t.id ? 700 : 500, fontSize: 12, borderBottom: `3px solid ${tab === t.id ? "#fff" : "transparent"}`, transition: "all 0.2s", fontFamily: "inherit" }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 480, margin: "0 auto", padding: "16px 16px 100px" }}>

        {/* ---- HISTORY ---- */}
        {tab === "checkin" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {visibleCheckins.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 48 }}>ยังไม่มีการเช็กอิน</div>}
            {visibleCheckins.map((c) => {
              const st = getStatus(c.status);
              return (
                <div key={c.id} style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.06)", border: "1.5px solid #f1f5f9", animation: "fadeIn 0.3s ease" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, color: "#1a56db", fontSize: 14 }}>{c.repId?.slice(1)}</div>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b" }}>{c.shopName}</div>
                        <div style={{ fontSize: 11, color: "#94a3b8" }}>{c.repName} · {c.province}</div>
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <span style={{ background: st.color + "18", color: st.color, padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700 }}>{st.label}</span>
                      <div style={{ fontSize: 10, color: "#cbd5e1", marginTop: 4 }}>{fmt(c.time)}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {c.hasPhoto && <span style={{ background: "#f0f9ff", color: "#0369a1", borderRadius: 6, padding: "3px 9px", fontSize: 11, fontWeight: 600 }}>📷 มีภาพ</span>}
                    {c.salesAmount > 0 && <span style={{ background: "#f0fdf4", color: "#15803d", borderRadius: 6, padding: "3px 9px", fontSize: 11, fontWeight: 700 }}>฿{c.salesAmount.toLocaleString()}</span>}
                    {c.note && <span style={{ background: "#fefce8", color: "#854d0e", borderRadius: 6, padding: "3px 9px", fontSize: 11 }}>💬 {c.note}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ---- SUMMARY ---- */}
        {tab === "summary" && <DailySummary checkins={visibleCheckins} />}

        {/* ---- ADMIN (manage permission only) ---- */}
        {tab === "admin" && perms.manage && (
          <div>
            <div style={{ background: "#fff", borderRadius: 14, padding: 4, marginBottom: 16, display: "flex", gap: 4, border: "1.5px solid #f1f5f9" }}>
              {[
                { id: "reps", label: "👥 พนักงาน", count: reps.length },
                { id: "customers", label: "🏪 ลูกค้า", count: customers.length },
              ].map((t) => (
                <button key={t.id} onClick={() => setAdminTab(t.id)} style={{ flex: 1, padding: "10px", border: "none", borderRadius: 10, cursor: "pointer", background: adminTab === t.id ? "#1e3a5f" : "transparent", color: adminTab === t.id ? "#fff" : "#64748b", fontWeight: adminTab === t.id ? 700 : 500, fontSize: 13, transition: "all 0.2s", fontFamily: "inherit" }}>
                  {t.label} <span style={{ background: adminTab === t.id ? "rgba(255,255,255,0.2)" : "#f1f5f9", borderRadius: 99, padding: "1px 7px", fontSize: 11 }}>{t.count}</span>
                </button>
              ))}
            </div>
            {adminTab === "reps" && <RepsManager reps={reps} setReps={setReps} showToast={showToast} />}
            {adminTab === "customers" && <CustomersManager customers={customers} setCustomers={setCustomers} showToast={showToast} />}
          </div>
        )}
      </div>

      {/* FAB — hide on admin tab and for manager role (view-only) */}
      {tab !== "admin" && user.role !== "manager" && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", zIndex: 200, width: "100%", maxWidth: 480, padding: "0 16px" }}>
          <button onClick={() => setShowForm(true)} style={{ width: "100%", background: "linear-gradient(135deg, #1a56db, #2563eb)", color: "#fff", border: "none", borderRadius: 14, padding: "16px", fontSize: 15, fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 24px rgba(26,86,219,0.4)", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <span style={{ fontSize: 20 }}>+</span> เช็กอินร้านค้า
          </button>
        </div>
      )}

      {/* Checkin Modal */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 500, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "#fff", width: "100%", maxWidth: 480, borderRadius: "20px 20px 0 0", padding: "20px 20px 32px", maxHeight: "92vh", overflowY: "auto", animation: "slideUp 0.35s cubic-bezier(0.34,1.56,0.64,1)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ fontWeight: 800, fontSize: 18, color: "#1e293b" }}>เช็กอินร้านค้า</div>
              <button onClick={() => setShowForm(false)} style={{ background: "#f1f5f9", border: "none", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 16, color: "#64748b" }}>✕</button>
            </div>
            <CheckinForm reps={reps} customers={customers} onSubmit={handleCheckin} onCancel={() => setShowForm(false)} lockedRepId={user.role === "sales" ? user.repId : null} />
          </div>
        </div>
      )}
    </div>
  );
}
